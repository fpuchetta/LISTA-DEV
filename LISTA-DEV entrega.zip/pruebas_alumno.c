#include "pa2m.h"
#include "src/lista.h"
#include "src/cola.h"
#include "src/pila.h"

void lista_crear_crea_lista_vacia()
{
	lista_t *lista = lista_crear();
	pa2m_afirmar(lista != NULL, "Lista creada correctamente");
	pa2m_afirmar((int)lista_tamanio(lista) == 0, "Lista creada esta vacia");
	pa2m_afirmar(lista_sacar_de_posicion(lista, 0) == NULL,
		     "Lista sacar de posicion devuelve null porque esta vacia");
	lista_destruir(lista);
}

void lista_insertar_elemento_inserta_correctamente()
{
	int uno = 1;
	lista_t *lista = lista_crear();
	pa2m_afirmar(lista_insertar(lista, &uno),
		     "Elemento insertado correctamente");
	pa2m_afirmar((int)lista_tamanio(lista),
		     "La lista tiene un elemento al insertar");
	int *obtenido = lista_obtener_elemento(lista, 0);
	pa2m_afirmar(
		*obtenido == 1,
		"Lista_obtener_elemento devuelve el elemento esperado (esperado : %i) | (devuelto: %i)",
		uno, *obtenido);
	lista_destruir(lista);
}
void lista_sacar_elemento_saca_correctamente()
{
	int uno = 1;
	lista_t *lista = lista_crear();
	lista_insertar(lista, &uno);
	int *obtenido = lista_sacar_elemento(lista, &uno);
	pa2m_afirmar(
		*obtenido == 1,
		"Lista_sacar_elemento devuelve el valor esperado (esperado: %i) | (devuelto: %i)",
		uno, *obtenido);
	pa2m_afirmar(lista_tamanio(lista) == 0,
		     "La lista achica su tamanio luego de sacar un elemento");
	lista_destruir(lista);
}
int main()
{
	pa2m_nuevo_grupo("============== Pruebas lista ===============");
	lista_crear_crea_lista_vacia();
	lista_insertar_elemento_inserta_correctamente();
	lista_sacar_elemento_saca_correctamente();
	return pa2m_mostrar_reporte();
}
